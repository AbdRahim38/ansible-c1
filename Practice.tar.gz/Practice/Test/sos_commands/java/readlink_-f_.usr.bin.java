/usr/bin/java
